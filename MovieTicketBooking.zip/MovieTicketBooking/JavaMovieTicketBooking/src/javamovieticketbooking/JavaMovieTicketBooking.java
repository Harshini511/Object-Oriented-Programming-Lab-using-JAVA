/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamovieticketbooking;

/**
 *
 * @author karthi
 */
public class JavaMovieTicketBooking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginFrame objectlogin=new LoginFrame(); 
        objectlogin.setVisible(true);
        //To start the front end - calling the login page
    }
    
}

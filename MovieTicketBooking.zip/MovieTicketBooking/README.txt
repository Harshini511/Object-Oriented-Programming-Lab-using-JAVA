Welcome to Movie Ticket Booking System.
------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------
This project has the following features:-
	1.Register if the user is new to use it.
	2.Log In if the user has already registered.
	3.Check previous booking details.
	4.Book tickets for different movies, as well as different shows.
	5.Add snacks to the booking alongwith tickets.
	6.Get the total amount one has to pay after booking.
	7.Generate the bill for future reference.
------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------
The following needs to be present with the following configurations:-
	1.MYSQL Server 5.5
		->It needs to have localhost as "3306"
		->It needs to have username as "root"
		->It needs to have password as "admin"
	2.JDK version atleast 1.8
------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------
After getting the required software,
copy the "register.sql", "booked.sql", "seatm.sql", "seata.sql", "seatd.sql", "seate.sql", "seatn.sql" from the MySQL folder (which is 
present in the JavaMovieTicketBooking folder in the zip file) to the following path ---> "C:\Program Files\MYSQL\MYSQL Server 5.5\bin"
and run the following commands in the MYSQL Server Client Line.
	
	mysql>create database register;
	mysql>use register;
	mysql>source register.sql;
	mysql>create database booked;
	mysql>use booked;
	mysql>source booked.sql;
	mysql>create database seatm;
	mysql>use seatm;
	mysql>source seatm.sql;
	mysql>create database seata;
	mysql>use seata;
	mysql>source seata.sql;
	mysql>create database seatd;
	mysql>use seatd;
	mysql>source seatd.sql;
	mysql>create database seate;
	mysql>use seate;
	mysql>source seate.sql;
	mysql>create database seatn;
	mysql>use seatn;
	mysql>source seatn.sql;

------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------
Then go to the JavaMovieTicketBooking folder in the zip file. There will be another folder called 'dist' inside it. Execute the 
JavaMovieTicketBooking.jar file.
------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------
		THANK YOU FOR USING HD CINEMAS MOVIE TICKET BOOKING SYSTEM